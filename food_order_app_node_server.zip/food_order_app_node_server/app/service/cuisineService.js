const fs = require("fs");

class Cuisines {
  constructor() {
    this.cuisines = JSON.parse(fs.readFileSync("./app/data/cuisines.json", "utf-8"));
  }
  // Method to retrieve all cuisines
  getAllCuisines() {
    return this.cuisines;
  }
   // Finding the cuisine in the cuisines array based on the provided ID
  getCuisineById(id) {
    const cuisine = this.cuisines.find((cuisine) => cuisine.id == id);
    return cuisine;
  }
  // Finding the cuisine in the cuisines array based on the provided name
  getCuisineByName(name) {
    const cuisine = this.cuisines.find((cuisine) => cuisine.name == name);
    return cuisine;
  } 
}

module.exports = Cuisines;